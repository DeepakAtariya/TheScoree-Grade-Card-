<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>FrontendIgnou</title>
  <base href="">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="{{ URL::asset('images/favicon.ico') }}">
<link rel="stylesheet" href="{{ URL::asset('css/styles.34e2d97d2672d313a034.css') }}"></head>
<body>
  <app-root></app-root>
<script type="text/javascript" src="{{ URL::asset('js/runtime.b57bf819d5bdce77f1c7.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/polyfills.05e428c7deb03eca82a1.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/scripts.90d9376b58c8fdaf3102.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/main.264b86b50060c25ce9b2.js') }}"></script>
</body>
</html>
