<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>FrontendIgnou</title>
  <base href="frontend/">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="stylesheet" href="styles.978a6a85d05b53bf3fec.css"></head>
<body>
  <app-root></app-root>
<script type="text/javascript" src="runtime.b57bf819d5bdce77f1c7.js"></script><script type="text/javascript" src="polyfills.05e428c7deb03eca82a1.js"></script><script type="text/javascript" src="scripts.2597d847beb18810beba.js"></script><script type="text/javascript" src="main.3175cdb23f6946343c1a.js"></script></body>
</html>
