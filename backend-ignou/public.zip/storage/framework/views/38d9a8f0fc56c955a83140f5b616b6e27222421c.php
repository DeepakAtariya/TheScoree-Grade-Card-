<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Score</title>
  <base href="">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="<?php echo e(URL::asset('css/favicon.ico')); ?> ">
<link rel="stylesheet" href="<?php echo e(URL::asset('css/styles.978a6a85d05b53bf3fec.css')); ?>"></head>
<body>
  <app-root></app-root>
<script type="text/javascript" src="<?php echo e(URL::asset('js/runtime.b57bf819d5bdce77f1c7.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/polyfills.05e428c7deb03eca82a1.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/scripts.2597d847beb18810beba.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/main.0006f905784fc835c790.js')); ?>"></script></body>
</html>
