
<form method="POST" action="testForm">
    <input type="text" name="name" placeholder="enter the name....">
    <input type="submit">
</form>

<?php echo e($name); ?>