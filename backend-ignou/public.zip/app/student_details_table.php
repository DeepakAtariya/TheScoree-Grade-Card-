<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class student_details_table extends Model
{
    //
}
